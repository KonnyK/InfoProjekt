
/**
 * Beschreiben Sie hier die Klasse Signal.
 * 
 * @author (Ihr Name) 
 * @version (eine Versionsnummer oder ein Datum)
 */
public class Signal extends TimingSimulator
{
    private String Name = ""; //noch keine Funktion au�er Konstruktor
    private Boolean Value = false;
    
    public Signal(String newName)
    {
        Name = newName;
    }

    public Boolean getValue(){
        return Value;
    }
    
    public void setValue(Boolean newValue){
        /**
        * Wird nur aufgerufen, wenn Eing�nge des Volladdieres durch simulate() ver�ndert werden
        * daher wird hier auch immer ein kompletter Durchlauf aller NandGatter gestartet
        */
        Value = newValue;
        PropagateSignals(); //alle Nand Gatter aktualisieren ihre Ausg�nge entsprechend ihrer Eing�nge
    }
        
    public void setInternValue(Boolean newValue){
        /**
         * Ver�ndert den Wert des Signals. Wird aufgerufen durch die Refresh Funktion eines Nands
         * welche das Output Signal desselben ver�ndert falls die Eing�nge das verlangen
         */
        Value = newValue; 
    }
}
